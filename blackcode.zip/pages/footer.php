</div>
<footer class="footer">
<div class="main-section">
CÔNG TY CỔ PHẦN PHÁT TRIỂN THỂ THAO ĐIỆN TỬ VIỆT NAM
<br>
Giấy CNĐKKD số 0103959912, cấp lần đầu ngày 09/06/2009 | Cơ quan cấp: Phòng Đăng ký kinh doanh - Sở Kế hoạch và đầu tư TP Hà Nội
<br>
Địa chỉ trụ sở chính: Tầng 29, Tòa nhà Trung tâm Lotte Hà Nội, số 54 đường Liễu Giai, Phường Cống Vị, Quận Ba Đình, TP Hà Nội, Việt Nam
<br>
Điện thoại: 024 73053939
</div>
<div class="container">
<nav class="footer-link-wrap">
<a class="footer-link-txt" href="#">Câu hỏi thường gặp</a> | <a class="footer-link-txt" href="#">Điều khoản sử dụng</a> | <a class="footer-link-txt" href="#">Chính sách bảo mật</a>
</nav>
<nav class="footer-link-wrap text-small">

</nav>
</div>
</footer>